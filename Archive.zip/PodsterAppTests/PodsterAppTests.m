//
//  PodsterAppTests.m
//  PodsterAppTests
//
//  Created by Stephen J Vanterpool on 8/25/12.
//
//

#import "PodsterAppTests.h"

@implementation PodsterAppTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in PodsterAppTests");
}

@end
