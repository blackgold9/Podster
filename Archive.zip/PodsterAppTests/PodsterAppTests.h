//
//  PodsterAppTests.h
//  PodsterAppTests
//
//  Created by Stephen J Vanterpool on 8/25/12.
//
//

#import <SenTestingKit/SenTestingKit.h>

@interface PodsterAppTests : SenTestCase

@end
