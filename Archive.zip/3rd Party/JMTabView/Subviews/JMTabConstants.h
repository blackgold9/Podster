//  Created by Jason Morrissey

#define kTabItemFont [UIFont boldSystemFontOfSize:12.]
#define kTabItemTextColor [UIColor whiteColor]
#define kTabItemPadding CGSizeMake(16., 10.)
#define kTabItemIconMargin 8.
#define kTabSpacing 14.
#define kTabSelectionAnimationDuration 0.3

