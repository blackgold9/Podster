//  Created by Jason Morrissey

#import <UIKit/UIKit.h>

@interface JMSelectionView : UIView 

@end
