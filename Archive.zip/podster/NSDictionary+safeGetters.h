//
//  NSDictionary+safeGetters.h
//  podster
//
//  Created by Vanterpool, Stephen on 1/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (safeGetters)
- (NSString* )stringForKey:(NSString *)key;
@end
