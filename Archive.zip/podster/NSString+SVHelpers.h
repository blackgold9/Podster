//
//  NSString+SVHelpers.h
//  podster
//
//  Created by Vanterpool, Stephen on 1/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SVHelpers)
+(NSString *)formattedStringRepresentationOfSeconds:(NSInteger)totalSeconds;
-(NSInteger)secondsFromDurationString;

- (NSDate *)dateFromRailsDate;

@end
