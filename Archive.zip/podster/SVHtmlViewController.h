//
//  SVHtmlViewController.h
//  podster
//
//  Created by Stephen Vanterpool on 6/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVHtmlViewController : UIViewController
@property (nonatomic, copy) NSString *html;
@end
