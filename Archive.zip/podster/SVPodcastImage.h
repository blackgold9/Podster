//
//  SVPodcastImage.h
//  podster
//
//  Created by Vanterpool, Stephen on 2/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVPodcastImage : UIImage

@end
