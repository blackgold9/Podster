//
//  Created by svanter on 1/9/12.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>


@interface SVCategory : NSObject
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) NSInteger categoryId;
@property (nonatomic, copy) NSURL *imageURL;
@end