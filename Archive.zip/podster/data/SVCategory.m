//
//  Created by svanter on 1/9/12.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import "SVCategory.h"


@implementation SVCategory {

}

@synthesize categoryId, name,imageURL;
@end