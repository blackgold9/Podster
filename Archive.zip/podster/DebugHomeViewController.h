//
//  DebugHomeViewController.h
//  podster
//
//  Created by Vanterpool, Stephen on 2/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DebugHomeViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UITextField *notificationTextField;

@end
