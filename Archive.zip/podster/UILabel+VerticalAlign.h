//
//  UILabel+VerticalAlign.h
//  podster
//
//  Created by Vanterpool, Stephen on 1/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (VerticalAlign)
- (void)alignTop;
- (void)alignBottom;
@end