cd ~/git/podster/podster
  mogenerator -m SVPodcastDatastore.xcdatamodeld/SVPodcastDatastore\ 20.xcdatamodel -O ./models --template-var arc=true

