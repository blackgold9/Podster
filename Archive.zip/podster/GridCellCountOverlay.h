//
//  GridCellCountOverlay.h
//  podster
//
//  Created by Vanterpool, Stephen on 4/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GridCellCountOverlay : UIView
- (void)setCount:(NSUInteger)theCount;
@end
