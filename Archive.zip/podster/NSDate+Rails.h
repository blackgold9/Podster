//
//  NSDate+Rails.h
//  podster
//
//  Created by Stephen J Vanterpool on 9/10/12.
//
//

#import <Foundation/Foundation.h>

@interface NSDate (Rails)

@end
