//
//  SVPodcastImage.m
//  podster
//
//  Created by Vanterpool, Stephen on 2/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SVPodcastImage.h"

@implementation SVPodcastImage

@end
