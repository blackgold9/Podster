//
// Created by svanter on 7/15/12.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>


@interface SVCustomGroupedTableViewController : UITableViewController
@end