//
//  UIImage+ForceDecompress.h
//  podster
//
//  Created by Vanterpool, Stephen on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ForceDecompress)
- (UIImage *)preloadedImage;
@end
