#import "PodcastImage.h"

@implementation PodcastImage

// Custom logic goes here.

@end
