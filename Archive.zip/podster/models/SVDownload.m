#import "SVDownload.h"
#import "SVPodcastEntry.h"
@implementation SVDownload

// Custom logic goes here.
//@synthesize downloadOperation;

@end
