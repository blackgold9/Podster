#import "_PodcastImage.h"

@interface PodcastImage : _PodcastImage {}
// Custom logic goes here.
@end
