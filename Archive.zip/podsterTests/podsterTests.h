//
//  PodsterTests.h
//  PodsterTests
//
//  Created by Stephen J Vanterpool on 8/25/12.
//
//

#import <SenTestingKit/SenTestingKit.h>

@interface PodsterTests : SenTestCase

@end
